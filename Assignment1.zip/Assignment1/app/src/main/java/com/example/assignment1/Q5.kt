package com.example.assignment1

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Q5 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q5)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btn : Button = findViewById(R.id.btn);
        val txt : TextView = findViewById(R.id.txt);
        val editTxt : EditText = findViewById(R.id.editTxt);

        btn.setOnClickListener(View.OnClickListener {
            val n : Int = (editTxt.text.toString()).toInt();

            var arr = ArrayList<Int>()
            arr.add(0);
            arr.add(1);

            var i : Int = 2;

            while (i < n) {
                arr.add(arr[i-2] + arr[i-1])
                i++;
            }
            i = 0;
            txt.setText("Fibonacci series upto $n : ");
            while(i < n) {
                txt.setText(txt.text.toString() + " , " +  arr[i].toString());
                i++;
            }
        })

    }
}