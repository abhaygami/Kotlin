package com.example.assignment1

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Q3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q3)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btn : Button = findViewById(R.id.btn);
        val txt : TextView = findViewById(R.id.txt);
        val editTxt : EditText = findViewById(R.id.editTxt);

        btn.setOnClickListener(View.OnClickListener {
            val num : Int = (editTxt.text.toString()).toInt();

            if(num%2 == 0) {
                txt.setText("$num is Even");
            } else {
                txt.setText("$num is Odd");
            }
        })

    }
}