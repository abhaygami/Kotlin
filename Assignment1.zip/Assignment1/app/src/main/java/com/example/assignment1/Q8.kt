package com.example.assignment1

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Q8 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q8)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnAdd : Button = findViewById(R.id.btnAdd);
        val txtAdd : TextView = findViewById(R.id.txtAdd);
        val editTxt : EditText = findViewById(R.id.editTxt);
        val btnFind : Button = findViewById(R.id.btnFind);
        val txtAns : TextView = findViewById(R.id.txtAns);

        var arr = ArrayList<Int>();
//        arr.add(0);

        btnAdd.setOnClickListener(View.OnClickListener {
            val x : Int = (editTxt.text.toString()).toInt();
            arr.add(x);
            txtAdd.setText("$x added to array!");
            editTxt.setText("");
        })

        btnFind.setOnClickListener(View.OnClickListener {
            txtAns.setText("Smallest Element : ${arr.min()}");
        })

    }
}