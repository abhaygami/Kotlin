package com.example.assignment1

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Q2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        val editText1 : EditText = findViewById(R.id.editText1);
        val editText2 : EditText = findViewById(R.id.editText2);
        val editText3 : EditText = findViewById(R.id.editText3);

        val btn : Button = findViewById(R.id.btn);

        var txtAns : TextView = findViewById(R.id.txtAns)

        btn.setOnClickListener(View.OnClickListener {
            val num1 : Int = (editText1.text.toString()).toInt();
            val num2 : Int = (editText2.text.toString()).toInt();
            val num3 : Int = (editText3.text.toString()).toInt();

            if(num1 >= num2 && num1 >= num3) {
                txtAns.setText("Largest : " + num1.toString());
            } else if(num2 >= num1 && num2 >= num3) {
                txtAns.setText("Largest : " + num2.toString());
            } else if(num3 >= num1 && num3 >= num2) {
                txtAns.setText("Largest : " + num3.toString());
            }
        })
    }
}