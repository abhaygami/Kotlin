package com.example.assignment1

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Q9 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q9)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val editTxt : EditText = findViewById(R.id.editTxt);
        val editTxt2 : EditText = findViewById(R.id.editTxt2);
        val btnAdd : Button = findViewById(R.id.btnAdd);
        val btnAddI : Button = findViewById(R.id.btnAddI);
        val btnRemove : Button = findViewById(R.id.btnRemove);
        val btnRemoveI : Button = findViewById(R.id.btnRemoveI);
        val btnSearch : Button = findViewById(R.id.btnSearch);
        val btnSearchI : Button = findViewById(R.id.btnSearchI);
        val btnDisplay : Button = findViewById(R.id.btnDisplay);
        val txtAns : TextView = findViewById(R.id.txtAns);

        val arr = ArrayList<Int>();

        btnAdd.setOnClickListener(View.OnClickListener {
            arr.add((editTxt.text.toString()).toInt());
            txtAns.setText("${(editTxt.text.toString()).toInt()} added to array");
            editTxt.setText("");
        })

        btnRemove.setOnClickListener(View.OnClickListener {
            if(arr.contains((editTxt.text.toString()).toInt())) {
                arr.remove((editTxt.text.toString()).toInt());
                txtAns.setText("${(editTxt.text.toString()).toInt()} removed from array");
                editTxt.setText("");
            } else {
                txtAns.setText("${(editTxt.text.toString()).toInt()} is not available in array");
                editTxt.setText("");
            }
        })

        btnRemoveI.setOnClickListener(View.OnClickListener {
            val i : Int = (editTxt.text.toString()).toIntOrNull() ?:0;
            if(arr.size <= i) {
                txtAns.setText("${i} index is not available in array");
                editTxt.setText("");
            } else {
                txtAns.setText("${arr[i]} element removed from array");
                editTxt.setText("");
                arr.removeAt(i);
            }
        })

        btnSearch.setOnClickListener(View.OnClickListener {
            val x : Int = (editTxt.text.toString()).toIntOrNull() ?:0;
            if (arr.contains(x)) {
                txtAns.setText("${x} is avilabe at ${arr.indexOf(x)} index in arraylist");
                editTxt.setText("");
            } else {
                txtAns.setText("${x} is not available in array");
                editTxt.setText("");
            }
        })

        btnSearchI.setOnClickListener(View.OnClickListener {
            val i : Int = (editTxt.text.toString()).toIntOrNull() ?:0;
            if(arr.size <= i) {
                txtAns.setText("${i} index is not available in array");
                editTxt.setText("");
            } else {
                txtAns.setText("at ${i} index element is ${arr[i]} in arraylist");
                editTxt.setText("");
            }
        })

        btnDisplay.setOnClickListener(View.OnClickListener {
            if(arr.size == 0) {
                txtAns.setText("Array is empty");
            } else {
                txtAns.setText("Array elements are : ");
                var i : Int = 0;
                while (i < arr.size) {
                    txtAns.setText(txtAns.text.toString() + "${arr[i]}" + " " );
                    i++;
                }
            }
        })

        btnAddI.setOnClickListener(View.OnClickListener {
            val i : Int = (editTxt2.text.toString()).toIntOrNull() ?: 0;
            val x : Int = (editTxt.text.toString()).toIntOrNull() ?: 0;

            if(arr.size <= i) {
                txtAns.setText("${i} index is not available in array");

            } else {
                arr.add(i,x);
                txtAns.setText("Element ${arr[i]} is entered at $i index");

            }
            editTxt2.setText("");
            editTxt.setText("");
        })
    }
}