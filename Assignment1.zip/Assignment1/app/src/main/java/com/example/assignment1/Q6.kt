package com.example.assignment1

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Q6 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q6)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnAdd : Button = findViewById(R.id.btnAdd);
        val txtAdd : TextView = findViewById(R.id.txtAdd);
        val editTxt : EditText = findViewById(R.id.editTxt);
        val btnCal : Button = findViewById(R.id.btnCal);
        val txtAns : TextView = findViewById(R.id.txtAns);

        var arr = ArrayList<Int>();

        btnAdd.setOnClickListener(View.OnClickListener {
            val x : Int = (editTxt.text.toString()).toIntOrNull() ?: 0;
            arr.add(x);
            txtAdd.setText("$x added to array!");
            editTxt.setText("");
        })

        btnCal.setOnClickListener(View.OnClickListener {
            txtAns.setText("Addition = ${arr.sum()} & Average = ${arr.average()}");
        })
    }
}