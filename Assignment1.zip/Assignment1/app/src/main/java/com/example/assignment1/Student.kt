package com.example.assignment1

open class Student {

}

class salary:Student() {

}