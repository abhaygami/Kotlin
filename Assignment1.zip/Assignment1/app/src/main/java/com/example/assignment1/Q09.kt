package com.example.assignment1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Q09 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q09)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

//    val editTxt : EditText = findViewById(R.id.editTxt);
//    val btnAdd : Button = findViewById(R.id.btnAdd);
//    val btnAddI : Button = findViewById(R.id.btnAddI);
//    val btnRemove : Button = findViewById(R.id.btnRemove);
//    val btnRemoveI : Button = findViewById(R.id.btnRemoveI);
//    val btnSearch : Button = findViewById(R.id.btnSearch);
//    val btnSearchI : Button = findViewById(R.id.btnSearchI);
//    val btnDisplay : Button = findViewById(R.id.btnDisplay);
//    val txtAns : TextView = findViewById(R.id.txtAns);
//
//    val arr = ArrayList<Int>();

//    btnAdd.



}