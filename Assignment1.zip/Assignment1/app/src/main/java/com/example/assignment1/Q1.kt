package com.example.assignment1

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Q1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q1)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btn1 : Button = findViewById(R.id.btn1);
        val btn2 : Button = findViewById(R.id.btn2);
        val btn3 : Button = findViewById(R.id.btn3);
        val btn4 : Button = findViewById(R.id.btn4);

        var txtAns : TextView = findViewById(R.id.txtAns);
        val editText1 : EditText = findViewById(R.id.editText1);
        val editText2 : EditText = findViewById(R.id.editText2);

5



        btn1.setOnClickListener(View.OnClickListener {
            var num1 : Double = (editText1.text.toString()).toDouble();
            var num2 : Double = (editText2.text.toString()).toDouble();
            txtAns.setText(num1.toString() + " + " + num2.toString() + " = " + ((num1 + num2).toString()));
        })

        btn2.setOnClickListener(View.OnClickListener {
            var num1 : Double = (editText1.text.toString()).toDouble();
            var num2 : Double = (editText2.text.toString()).toDouble();
            txtAns.setText(num1.toString() + " - " + num2.toString() + " = " + ((num1 - num2).toString()));
        })

        btn3.setOnClickListener(View.OnClickListener {
            var num1 : Double = (editText1.text.toString()).toDouble();
            var num2 : Double = (editText2.text.toString()).toDouble();
            txtAns.setText(num1.toString() + " * " + num2.toString() + " = " + ((num1 * num2).toString()));
        })

        btn4.setOnClickListener(View.OnClickListener {
            var num1 : Double = (editText1.text.toString()).toDouble();
            var num2 : Double = (editText2.text.toString()).toDouble();
            txtAns.setText(num1.toString() + " / " + num2.toString() + " = " + ((num1 / num2).toString()));
        })
    }
}