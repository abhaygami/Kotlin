package com.example.assignment2

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Q02 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q02)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val edtRollno : EditText = findViewById(R.id.edtRollno);
        val edtName : EditText = findViewById(R.id.edtName);
        val edtM1 : EditText = findViewById(R.id.edtM1);
        val edtM2 : EditText = findViewById(R.id.edtM2);
        val edtM3 : EditText = findViewById(R.id.edtM3);
        val btnAdd : Button = findViewById(R.id.btnAdd);
        val btnDisplayAll : Button = findViewById(R.id.btnDisplayAll);
        val btnDisplayFirst : Button = findViewById(R.id.btnDisplayFirst);
        val txtAns : TextView = findViewById(R.id.txtAns);
        val txtCheck : TextView = findViewById(R.id.txtCheck);

        var arr = ArrayList<Student>();


        btnAdd.setOnClickListener(View.OnClickListener {
            var obj = Student((edtRollno.text.toString().toInt()),(edtName.text.toString()),(edtM1.text.toString().toInt()),(edtM2.text.toString().toInt()),(edtM3.text.toString().toInt()));
            arr.add(obj);
            txtCheck.setText("Data inserted for ${obj.name}");
            edtRollno.setText("");
            edtName.setText("");
            edtM1.setText("");
            edtM2.setText("");
            edtM3.setText("");
            txtAns.setText("");
        })

        btnDisplayAll.setOnClickListener(View.OnClickListener {
            txtAns.setText("");
            for (rec in arr) {
                txtAns.setText(txtAns.text.toString() + "${rec.displayAll()}\n");
            }
            txtCheck.setText("");
        })

        btnDisplayFirst.setOnClickListener(View.OnClickListener {
            var tmp : Double = 0.0;
            for (rec in arr) {
                if (tmp < rec.percentage) {
                    tmp = rec.percentage;
                }
            }

            for (rec in arr) {
                if(tmp == rec.percentage) {
                    txtAns.setText("${rec.displayAll()}\n");
                }
            }
            txtCheck.setText("");
        })


    }
}

class Student(var rollNo : Int,var name : String,var m1 : Int,var m2 : Int,var m3 : Int) {
    var total : Int = m1 + m2 + m3;
    var percentage : Double = (total/3).toDouble();
    var grade : String = if (percentage >= 80) "A" else if (percentage >= 60) "B" else "C";

    fun displayAll() : String {
        return "$rollNo $name $total $percentage $grade";
    }


}