package com.example.assignment2

import android.icu.text.SimpleDateFormat
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.sql.Date
import java.util.Calendar

class Q01 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q01)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val edtCode : EditText = findViewById(R.id.edtCode);
        val edtName : EditText = findViewById(R.id.edtName);
        val edtDes : EditText = findViewById(R.id.edtDes);
        val edtDOB : EditText = findViewById(R.id.edtDOB);
        val edtDOJ : EditText = findViewById(R.id.edtDOJ);
        val edtBS : EditText = findViewById(R.id.edtBS);
        val edtDept : EditText = findViewById(R.id.edtDept);

        val txtCheck : TextView = findViewById(R.id.txtCheck);
        val txtAns : TextView = findViewById(R.id.txtAns);

        val btnAdd : Button = findViewById(R.id.btnAdd);
        val btnDisplayAll : Button = findViewById(R.id.btnDisplayAll);
        val btnSearchSales : Button = findViewById(R.id.btnSearchSales);
        val btnSearchExp : Button = findViewById(R.id.btnSearchExp);

        var arr = ArrayList<Employee>();

        btnAdd.setOnClickListener(View.OnClickListener {
            var obj = Employee((edtCode.text.toString().toInt()),(edtName.text.toString()), (edtDes.text.toString()) , (edtDOB.text.toString()),(edtDOJ.text.toString()) , (edtBS.text.toString().toDouble()),(edtDept.text.toString()));
            obj.calAll();
            arr.add(obj);
            txtCheck.setText("Details for ${obj.name} is added");
            txtAns.setText("");
            edtName.setText("");
            edtDept.setText("");
            edtDOJ.setText("");
            edtBS.setText("");
            edtCode.setText("");
            edtDes.setText("");
            edtDOB.setText("");
        })

        btnDisplayAll.setOnClickListener(View.OnClickListener {
            txtCheck.setText("");
            txtAns.setText("");
            for (rec in arr) {
                txtAns.setText(txtAns.text.toString() + rec.displayData() + "\n");
            }
        })

        btnSearchSales.setOnClickListener(View.OnClickListener {
            txtCheck.setText("");
            txtAns.setText("");
            for (rec in arr) {
                if(rec.dept == "sales") {
                    txtAns.setText(txtAns.text.toString() + rec.displayData() + "\n");
                }
            }
        })

        btnSearchExp.setOnClickListener(View.OnClickListener {
            txtCheck.setText("");
            txtAns.setText("");
            for (rec in arr) {
                if(rec.exp >= 5) {
                    txtAns.setText(txtAns.text.toString() + rec.displayData() + "\n");
                }
            }
        })


    }
}

class Employee(var code : Int, var name: String, var des : String , var DOB : String, var DOJ : String, var basicSalary : Double, var dept : String ) {

    var da : Double = 0.0;
    var hra : Double = 0.0;
    var totalSal : Double = 0.0;
    var exp : Int = 0;



    fun calAll() {
        if(basicSalary <= 30000) {
            da = 0.60;
            hra = 0.20;
        } else if (basicSalary > 30000 && basicSalary <= 45000) {
            da = 0.70;
            hra = 0.30;
        } else {
            da = 0.85;
            hra = 0.40;
        }

        totalSal = basicSalary + (da * basicSalary) + (hra * basicSalary);

        val time = Calendar.getInstance().time;
        val formatter = SimpleDateFormat("dd/MM/yyyy");
        val current = formatter.format(time);

        val mDate11 = formatter.parse(current);
        val mDate22 = formatter.parse(DOJ);
        val mDifference = kotlin.math.abs(mDate11.time - mDate22.time);
        exp = (mDifference / (365.25 * 24 * 60 * 60 * 1000)).toInt();

    }

    fun displayData() : String {
        return "$code || $name || $totalSal || $dept || $exp";
    }

}