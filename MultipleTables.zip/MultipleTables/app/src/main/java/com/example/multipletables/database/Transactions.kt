package com.example.multipletables.database

data class Transactions(var transactionId : Int, var accNo : Int, var amount : Int)
