package com.example.multipletables.database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class SQLiteHelper(context: Context) : SQLiteOpenHelper(context,dbName,null,version) {
    override fun onCreate(db: SQLiteDatabase?) {
        var q1 = "CREATE TABLE $tbl1 ($col11 INTEGER PRIMARY KEY, $col12 TEXT, $col13 TEXT, $col14 TEXT, $col15 INTEGER)";
        db?.execSQL(q1);

        var q2 = "CREATE TABLE $tbl2 ($col21 INTEGER PRIMARY KEY, $col22 TEXT, $col23 TEXT, $col24 TEXT)";
        db?.execSQL(q2);

        var q3 = "CREATE TABLE $tbl3 ($col31 INTEGER PRIMARY KEY, $col32 INTEGER, $col33 INTEGER)";
        db?.execSQL(q3);
    }

    override fun onUpgrade(
        db: SQLiteDatabase?,
        oldVersion: Int,
        newVersion: Int
    ) {
        db?.execSQL("DROP TABLE IF EXISTS $tbl1");
        db?.execSQL("DROP TABLE IF EXISTS $tbl2");
        db?.execSQL("DROP TABLE IF EXISTS $tbl3");

        onCreate(db);
    }

    companion object {
        private var dbName = "BankDB";
        private var version = 1;

        // Customer Table
        private var tbl1 = "Customer";
        private var col11 = "accNo";
        private var col12 = "name";
        private var col13 = "username";
        private var col14 = "password";
        private var col15 = "balance";

        // Staff Table
        private var tbl2 = "Staff";
        private var col21 = "staffId";
        private var col22 = "name";
        private var col23 = "username";
        private var col24 = "password";

        // Transaction table
        private var tbl3 = "Transactions";
        private var col31 = "transactionId";
        private var col32 = "accNo";
        private var col33 = "amount";
    }

    fun registerCustomer(customer: Customer) : Boolean {
        var db = this.writableDatabase;
        var values = ContentValues();
        values.put(col11,customer.accNo);
        values.put(col12,customer.name);
        values.put(col13,customer.username);
        values.put(col14,customer.password);
        values.put(col15,customer.balance);

        var res = (db.insert(tbl1,null,values)).toInt();

        if(res == -1) {
            return false;
        } else {
            return true;
        }
    }

    fun registerStaff(staff: Staff) : Boolean {
        var db = this.writableDatabase;
        var values = ContentValues();
        values.put(col21,staff.staffId);
        values.put(col22,staff.name);
        values.put(col23,staff.username);
        values.put(col24,staff.password);

        var res = (db.insert(tbl2,null,values)).toInt();

        if(res == -1) {
            return false;
        } else {
            return true;
        }
    }

    fun getCustomerDetails(username : String, password : String) : Cursor {
        val db = this.readableDatabase;
        var cursor : Cursor?=null;
        cursor = db.rawQuery("SELECT * FROM $tbl1 WHERE $col13 = '$username' AND $col14 = '$password'",null);
        return cursor;
    }

    fun getStaffDetails(username : String, password : String) : Cursor {
        val db = this.readableDatabase;
        var cursor : Cursor?=null;
        cursor = db.rawQuery("SELECT * FROM $tbl2 WHERE $col23 = '$username' AND $col24 = '$password'",null);
        return cursor;
    }

    fun loginCustomer(username : String, password : String) : Boolean {
        var cursor : Cursor?=null;
        cursor = getCustomerDetails(username,password);

        if(cursor.moveToFirst()) {
            return true;
        } else {
            return false;
        }
    }

    fun loginStaff(username : String, password : String) : Boolean {
        var cursor : Cursor?=null;
        cursor = getStaffDetails(username,password);

        if(cursor.moveToFirst()) {
            return true;
        } else {
            return false;
        }
    }

    fun checkBalance(username: String, password: String) : Int {
        val cursor = getCustomerDetails(username,password);

        if (cursor.moveToFirst()) {
            return cursor.getInt(4)
        } else {
            return -1
        }
    }

    fun editPassword(username: String, password: String, newPass : String) : Boolean {
        val db = this.writableDatabase;
        var values = ContentValues();

        values.put(col14,newPass);

        var res = (db.update(tbl1,values,"$col13 = '$username' AND $col14 = '$password'",null)).toInt();

        if(res == 0) {
            return false;
        } else {
            return true;
        }
    }

    fun fetchAllAccNo() : Cursor {
        val db = this.readableDatabase;
        val cursor = db.rawQuery("SELECT $col11 FROM $tbl1",null);

        return cursor;
    }

    fun searchCustomer(accNo : Int) : String {
        val db = this.readableDatabase;
        val cursor = db.rawQuery("SELECT * FROM $tbl1 WHERE $col11 = $accNo",null);
        if(cursor.moveToFirst()) {
            return "Account No : ${cursor.getString(0)}\n" +
                    "Name : ${cursor.getString(1)}\n" +
                    "Username : ${cursor.getString(2)}";
        }
        return "";
    }

    fun deleteCustomer(accNo: Int) : Boolean {
        val db = this.writableDatabase;

        val res = (db.delete(tbl1,"$col11 = $accNo",null)).toInt();
        if(res == 0) {
            return false;
        } else {
            return true;
        }
    }

    fun fetchAllCustomer() : Cursor {
        val db = this.readableDatabase;
        val cursor = db.rawQuery("SELECT * FROM $tbl1",null);

        return cursor;
    }
}