package com.example.multipletables.database

data class Staff(var staffId : Int, var name : String, var username : String, var password : String)
