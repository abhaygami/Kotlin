package com.example.multipletables

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.multipletables.database.SQLiteHelper

class StaffDashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_staff_dashboard)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnSearch = findViewById<Button>(R.id.btnSearch);
        val btnDelete = findViewById<Button>(R.id.btnDelete);
        val btnLogout = findViewById<Button>(R.id.btnLogout);
        val actxtAccNo = findViewById<AutoCompleteTextView>(R.id.actxtAccNo);
        val lv1 = findViewById<ListView>(R.id.lv1);

        val arrCustomer = ArrayList<String>();
        val arr = ArrayList<String>();

        val helper = SQLiteHelper(this);
        val cursor = helper.fetchAllAccNo();

        if (cursor.moveToFirst()) {
            do {
                arr.add("${cursor.getString(0)}");
            } while (cursor.moveToNext());
        }

        val arrAdapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,arr);
        actxtAccNo.setAdapter(arrAdapter);

        btnSearch.setOnClickListener {
            val accNo = actxtAccNo.text.toString().toInt();
            val res = helper.searchCustomer(accNo);

            arrCustomer.clear();
            if(res != "") {
                arrCustomer.add(res);
                val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, arrCustomer);
                lv1.adapter = adapter;
            } else {
                Toast.makeText(this,"No Customer Found", Toast.LENGTH_LONG).show();
            }
        }

        btnDelete.setOnClickListener {
            val accNo = actxtAccNo.text.toString().toInt();
            val res = helper.deleteCustomer(accNo);

            if(res) {
                Toast.makeText(this,"Customer deleted successfully", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this,"Customer can't be deleted ", Toast.LENGTH_LONG).show();
            }
        }

        btnLogout.setOnClickListener {
            val intent = Intent(this, Login::class.java);
            startActivity(intent);
        }
    }
}