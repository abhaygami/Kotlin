package com.example.multipletables

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.multipletables.database.SQLiteHelper

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val edtUsername = findViewById<EditText>(R.id.edtUsername);
        val edtPassword = findViewById<EditText>(R.id.edtPassword);
        val btnLogin = findViewById<Button>(R.id.btnLogin);
        val txtRegister = findViewById<TextView>(R.id.txtRegister);
        val spinnerRole = findViewById<Spinner>(R.id.spinnerRole);

        val arr = arrayOf("Customer","Staff");
        val arrAdapter = ArrayAdapter(this,android.R.layout.simple_spinner_item,arr);
        spinnerRole.adapter = arrAdapter;

        val helper = SQLiteHelper(this);

        txtRegister.setOnClickListener {
            val intent = Intent(this, Register::class.java);
            startActivity(intent);
        }

        btnLogin.setOnClickListener {
            val username = edtUsername.text.toString();
            val password = edtPassword.text.toString();

            if(spinnerRole.selectedItemPosition == 0) {
                val res = helper.loginCustomer(username,password);
                if(res) {
                    Toast.makeText(this,"Login of Customer is Done!!", Toast.LENGTH_LONG).show();
                    val intent = Intent(this, CustomerDashboard::class.java);
                    intent.putExtra("username",username);
                    intent.putExtra("password",password);
                    startActivity(intent);
                } else {
                    Toast.makeText(this,"Invalid username Or password", Toast.LENGTH_LONG).show();
                }
            } else {
                val res = helper.loginStaff(username,password);
                if(res) {
                    Toast.makeText(this,"Login of Staff Done!!", Toast.LENGTH_LONG).show();
                    val intent = Intent(this, StaffDashboard::class.java);
                    intent.putExtra("username",username);
                    intent.putExtra("password",password);
                    startActivity(intent);
                } else {
                    Toast.makeText(this,"Invalid username Or password", Toast.LENGTH_LONG).show();
                }
            }
        }
    }
}