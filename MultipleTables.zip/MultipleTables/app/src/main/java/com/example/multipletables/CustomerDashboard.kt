package com.example.multipletables

import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.multipletables.database.SQLiteHelper

class CustomerDashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_customer_dashboard)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val txtDetails = findViewById<TextView>(R.id.txtDetails);
        val btnCheckBalance = findViewById<Button>(R.id.btnCheckBalance);
        val btnEditPassword = findViewById<Button>(R.id.btnEditPassword);
        val btnLogout = findViewById<Button>(R.id.btnLogout);
        val edtNewPass = findViewById<EditText>(R.id.edtNewPass);


        val username = intent.getStringExtra("username").toString();
        val password = intent.getStringExtra("password").toString();

        val helper = SQLiteHelper(this);

        var cursor : Cursor?= null;
        cursor = helper.getCustomerDetails(username,password);

        if(cursor.moveToFirst()) {
            txtDetails.setText("Account No : ${cursor.getString(0)}\nName : ${cursor.getString(1)}\nusername : ${cursor.getString(2)}\n");
        }

        btnLogout.setOnClickListener {
            val intent = Intent(this, Login::class.java);
            startActivity(intent);
        }

        btnCheckBalance.setOnClickListener {
            val balance = helper.checkBalance(username,password);

            if(balance != -1) {
                Toast.makeText(this,"Available Balance = $balance", Toast.LENGTH_LONG).show();
            }
        }

        btnEditPassword.setOnClickListener {
            val newPass = edtNewPass.text.toString();
            val res = helper.editPassword(username,password,newPass);

            if(res) {
                Toast.makeText(this,"Password Updated", Toast.LENGTH_LONG).show();
                val intent = Intent(this, Login::class.java);
                startActivity(intent);
            } else {
                Toast.makeText(this,"Password not Updated", Toast.LENGTH_LONG).show();
            }
        }
    }
}