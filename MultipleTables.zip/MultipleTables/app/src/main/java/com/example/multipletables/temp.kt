package com.example.multipletables

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.multipletables.database.Customer
import com.example.multipletables.database.SQLiteHelper
import kotlin.random.Random

class temp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_temp)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val lv1 = findViewById<ListView>(R.id.lv1);
        val btnDisplay = findViewById<Button>(R.id.btnDisplay);
        val btnAdd = findViewById<Button>(R.id.btnAdd);
        val edtName = findViewById<EditText>(R.id.edtName);
        val edtUsername = findViewById<EditText>(R.id.edtUsername);
        val edtPassword = findViewById<EditText>(R.id.edtPassword);
        val helper = SQLiteHelper(this);
        val arr = ArrayList<String>();

        btnAdd.setOnClickListener {
            val accNo = Random.nextInt(50,100);
            val name = edtName.text.toString();
            val username = edtUsername.text.toString();
            val password = edtPassword.text.toString();
            val balance = 50000;

            val res = helper.registerCustomer(Customer(accNo,name,username,password,balance));

            if(res) {
                Toast.makeText(this,"Registration Done", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this,"Registration Failed", Toast.LENGTH_LONG).show();
            }
        }

        btnDisplay.setOnClickListener {
            val cursor = helper.fetchAllCustomer();
            arr.clear();
            if (cursor.moveToFirst()) {
                do {
                    arr.add("AccNo : ${cursor.getString(0)} || Name : ${cursor.getString(1)} || Balance : ${cursor.getString(4)}");
                } while (cursor.moveToNext());
            }
            val arrAdapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,arr);
            lv1.adapter = arrAdapter;
        }
    }
}