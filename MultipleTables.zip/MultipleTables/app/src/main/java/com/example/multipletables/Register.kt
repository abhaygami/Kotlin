package com.example.multipletables

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.multipletables.database.Customer
import com.example.multipletables.database.SQLiteHelper
import com.example.multipletables.database.Staff
import kotlin.random.Random

class Register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val edtName = findViewById<EditText>(R.id.edtName);
        val edtUsername = findViewById<EditText>(R.id.edtUsername);
        val edtPassword = findViewById<EditText>(R.id.edtPassword);
        val btnRegister = findViewById<Button>(R.id.btnRegister);
        val txtLogin = findViewById<TextView>(R.id.txtLogin);
        val spinnerRole = findViewById<Spinner>(R.id.spinnerRole);

        val arr = arrayOf("Customer","Staff");
        val arrAdapter = ArrayAdapter(this,android.R.layout.simple_spinner_item,arr);
        spinnerRole.adapter = arrAdapter;

        val helper = SQLiteHelper(this);

        txtLogin.setOnClickListener {
            val intent = Intent(this, Login::class.java);
            startActivity(intent);
        }

        btnRegister.setOnClickListener {
            val id = Random.nextInt(10000,999999);
            val name = edtName.text.toString();
            val username = edtUsername.text.toString();
            val password = edtPassword.text.toString();
            if(spinnerRole.selectedItemPosition == 0) {
//                Customer Selected
                val res = helper.registerCustomer(Customer(id,name,username,password,50000));
//                By Default opening Balance 50000
                if(res) {
                    Toast.makeText(this,"Registration of customer is Done !!", Toast.LENGTH_LONG).show();
                    val intent = Intent(this, Login::class.java);
                    startActivity(intent);
                } else {
                    Toast.makeText(this,"Registration of customer Failed !!", Toast.LENGTH_LONG).show();
                }
            } else {
//                Staff Selected
                val res = helper.registerStaff(Staff(id,name,username,password));
                if(res) {
                    Toast.makeText(this,"Registration of Staff is Done !!", Toast.LENGTH_LONG).show();
                    val intent = Intent(this, Login::class.java);
                    startActivity(intent);
                } else {
                    Toast.makeText(this,"Registration of Staff Failed !!", Toast.LENGTH_LONG).show();
                }
            }
        }

    }
}