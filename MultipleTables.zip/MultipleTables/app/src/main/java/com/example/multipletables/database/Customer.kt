package com.example.multipletables.database

data class Customer(var accNo : Int, var name : String, var username : String, var password : String, var balance : Int)
